function redirecttologin() {
    let img = document.getElementById("login")
    window.location.href = "loginpage2.html";
}


function redirecttocart() {
    window.open("cart.html", "_blank");
}


function redirecttoregister() {
    let div = document.getElementById("ToRegister");
    window.location.href = "register.html";
}

function GoBacktoHome() {
    window.location.href = "index.html";
}

function redirecttocheckout() {
    let img = document.getElementById("checkout-btn")
    window.location.href = "checkout.html";

}
