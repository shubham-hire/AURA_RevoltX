# To run the backend server 

    step1: 
    
        cd ~/Desktop/AURA_MAIN

    step2 : 
    
        node server.js

    step3 : 
        <!-- Paste this in your browser -->
        http://localhost:3000/index.html

















